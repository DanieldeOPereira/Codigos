/*
		Modulo BT movel (escravo)
		- Fica visivel para Inquiry e conexão
		- Ao ser conectado, espera uma senha de x caracteres
		- Se senha certa, envia dados de GPS(a definir) e fecha conexão
		- Se errada, fecha a conexão
		- Será passivo na comunicação do BT
*/

/*
	Pendencias:
	-Setup
	-Definir o que é necessario configurar manualmente no modulo BT
	-string_parser
	-Listar comandos necessarios no modulo BT
	-Função de parser do GPS

	FAZER UMA BIBLIOTECA PROPIA PARA O BT E GPS
*/

#include "uart.h"
#include "bluetooth.h"
#include "string_parse.h"
#include "gps.h"

#include "uart.h"
#include "bluetooth.h"
#include "string_parse.h"
#include "stdio.h"
#include "inc/tm4c1294ncpdt.h"
#include "inc/hw_types.h"
//#include "inc/hw_ints.h"
#include "inc/hw_types.h"
#include "inc/hw_memmap.h"

#include "driverlib/rom.h"
#include "driverlib/rom_map.h"
#include <stdint.h>
#include <stdbool.h>
#include <stdio.h>
#include <string.h>


#include "driverlib/gpio.h"
#include "driverlib/sysctl.h"
#include "driverlib/pin_map.h"
#include "driverlib/interrupt.h"
#include "driverlib/timer.h"

#include "driverlib/pwm.h"
#include "driverlib/uart.h"

#include "inc/hw_gpio.h"

#define BREAK_CONNECTION_CARACTER '%'
#define TEST_CONNECTION_CARACTER '+'
#define CONNECT 0
#define ECHO 1 // 1 = on, 0 = off
#define TIMEOUT_PASSWORD 10000 // em milisegundos




/*  Global control variables  */
volatile unsigned char isBusy=0; // 0 = not busy, 1 = busy
volatile unsigned char lastActivity=0; // 0 = just started, need to setup module
volatile unsigned char stringPronta=0; // 0 = não esta pronta, 1 = esta pronta
volatile unsigned char connection_updated = 0; // 0 = nenhum evento de conexão pendente, 1 = recebeu %
volatile unsigned int timeout = 0;


void delay_ms(unsigned int time_ms){
	unsigned int i;
	for(i=0; i < time_ms; i++)
		__delay_cycles(120000);	// delay de 1ms, assumindo clock_frequency = 120MHz
}

// Não definido 100%
// Coleta e salva periodicamente dados de GPS
// 0,1 Hz
void timer1_interrupt(void){
	TimerIntClear(TIMER0_BASE, TIMER_TIMA_TIMEOUT);
	//TODO chamar atualização do gps
}

//timeout timer interrupt
//10 hz
void timer2_interrupt(void){
	TimerIntClear(TIMER1_BASE, TIMER_TIMA_TIMEOUT);
	if(timeout > 0 )
		timeout-= 100; // -100 milisegundos
}

// debug PC -> tiva
void uart0_interrupt(void)
{
	unsigned char _c;
	unsigned long ulStatus = UARTIntStatus(UART0_BASE, true);
	UARTIntClear(UART0_BASE, ulStatus);

	while(UARTCharsAvail(UART0_BASE))
	{
		_c = UARTCharGet(UART0_BASE);
		while (UARTBusy(UART3_BASE));
		UARTCharPut(UART3_BASE, _c);
		UARTCharPut(UART0_BASE, _c);
	}
}

//Handles BT strings and detect \n (end of line)
void uart3_interrupt(void){
	/*
		Comportamentos esperados:
		-Detecta \n para saber o fim de linha e chamar função de tratamento
		-Quando receber '*' responder '*' para confirmar conexão
	*/

	//Variavel auxiliar
	unsigned char _c;
	// Pega o valor das flags de interrpção da UART3
	unsigned long ulStatus = UARTIntStatus(UART3_BASE, true);
	// Limpa flag de interrupção
	UARTIntClear(UART3_BASE, ulStatus);

	while(UARTCharsAvail(UART3_BASE))
	{
		_c = UARTCharGet(UART3_BASE);

		// Se echo = 1, replica tudo para UART de debug
		if(ECHO==1)
		UARTCharPut(UART0_BASE, _c);

		if(salvar_caracter(_c,TEST_CONNECTION_CARACTER) == 2)
		{
			UARTCharPut(UART3_BASE, _c);
			UARTCharPut(UART3_BASE, '\n');
		}
		if( _c == '\n' )
			stringPronta=1;
		if(_c == BREAK_CONNECTION_CARACTER){
			connection_updated = 1;
			delay_ms(100);
		}
	}

}

void uart7_interrupt(void){
	unsigned char _c;
	unsigned long ulStatus = UARTIntStatus(UART7_BASE, true);
	UARTIntClear(UART7_BASE, ulStatus);

	while(UARTCharsAvail(UART7_BASE))
	{
		_c = UARTCharGet(UART7_BASE);

		// Se echo = 1, replica tudo para UART de debug
		if(ECHO==1)
			UARTCharPut(UART0_BASE, _c);
		//TODO colocar chamada funcao de salvar no buffer do gps aqui

	}
}

void setup(void){
	//Setup clock
	SysCtlClockFreqSet((SYSCTL_XTAL_25MHZ|SYSCTL_OSC_MAIN|SYSCTL_USE_PLL|SYSCTL_CFG_VCO_480), 120000000);

	//Enable peripherals
	SysCtlPeripheralEnable(SYSCTL_PERIPH_UART3);
	SysCtlPeripheralEnable(SYSCTL_PERIPH_UART0);
	SysCtlPeripheralEnable(SYSCTL_PERIPH_UART7);
	SysCtlPeripheralEnable(SYSCTL_PERIPH_TIMER0);
	SysCtlPeripheralEnable(SYSCTL_PERIPH_TIMER1);
	SysCtlPeripheralEnable(SYSCTL_PERIPH_GPIOA);
	SysCtlPeripheralEnable(SYSCTL_PERIPH_GPIOC);

	while (!SysCtlPeripheralReady(SYSCTL_PERIPH_GPIOA));
	while (!SysCtlPeripheralReady(SYSCTL_PERIPH_GPIOC));
	while (!SysCtlPeripheralReady(SYSCTL_PERIPH_TIMER1));
	while (!SysCtlPeripheralReady(SYSCTL_PERIPH_TIMER0));
	while (!SysCtlPeripheralReady(SYSCTL_PERIPH_UART3));
	while (!SysCtlPeripheralReady(SYSCTL_PERIPH_UART0));
	while (!SysCtlPeripheralReady(SYSCTL_PERIPH_UART7));

	//Setup UART3 at 115200, connected to RN-41 bluetooth device
	GPIOPinConfigure(GPIO_PA4_U3RX);
	GPIOPinConfigure(GPIO_PA5_U3TX);
	GPIOPinTypeUART(GPIO_PORTA_BASE, GPIO_PIN_4 | GPIO_PIN_5);
	UARTConfigSetExpClk(UART3_BASE, 120000000, 115200,
			(UART_CONFIG_WLEN_8 | UART_CONFIG_STOP_ONE |
					UART_CONFIG_PAR_NONE));
	UARTFIFODisable(UART3_BASE);
	//UARTFIFOLevelSet(UART3_BASE,UART_FIFO_TX1_8,UART_FIFO_RX2_8);
	UARTIntRegister(UART3_BASE, uart3_interrupt);
	UARTIntEnable(UART3_BASE, UART_INT_RX);

	//Setup UART0 at 9600 for debug (echo needs to be 1)
	GPIOPinConfigure(GPIO_PA0_U0RX);
	GPIOPinConfigure(GPIO_PA1_U0TX);
	GPIOPinTypeUART(GPIO_PORTA_BASE, GPIO_PIN_0 | GPIO_PIN_1);
	UARTConfigSetExpClk(UART0_BASE, 120000000, 115200,
			(UART_CONFIG_WLEN_8 | UART_CONFIG_STOP_ONE |
					UART_CONFIG_PAR_NONE));
	UARTFIFODisable(UART0_BASE);
	UARTIntRegister(UART0_BASE, uart0_interrupt);
	UARTIntEnable(UART0_BASE, UART_INT_RX);

	//Setup UART7 for GPS module
	//TODO não esta funcionando
	GPIOPinConfigure(GPIO_PC4_U7RX);
	GPIOPinConfigure(GPIO_PC5_U7TX);
	GPIOPinTypeUART(GPIO_PORTC_BASE, GPIO_PIN_4 | GPIO_PIN_5);
	UARTConfigSetExpClk(UART7_BASE, 120000000, 9600,
			(UART_CONFIG_WLEN_8 | UART_CONFIG_STOP_ONE |
					UART_CONFIG_PAR_NONE));
	UARTFIFODisable(UART7_BASE);
	UARTIntRegister(UART7_BASE, uart7_interrupt);
	UARTIntEnable(UART7_BASE, UART_INT_RX);

	//Setup timers to control the firmware
	// Timeout Timer
	//Timer1 configuration
	TimerConfigure(TIMER1_BASE, TIMER_CFG_PERIODIC);//configura timer1 para onda completa
	TimerLoadSet(TIMER1_BASE, TIMER_A, 12000000);//configura o timerA para um periodo de 10hz
	IntRegister(INT_TIMER1A, timer2_interrupt);//associa a interrupção do timer1_A a função "timer2_interrupt"
	IntEnable(INT_TIMER1A);								//habilita o timer1_A
	TimerIntEnable(TIMER1_BASE, TIMER_TIMA_TIMEOUT);
	TimerEnable(TIMER1_BASE, TIMER_A);

}

void receive_password(void){
	unsigned char resposta = 0, aux=0;
	//char password[17] = {'1','2','3','4','1','2','3','4','1','2','3','4','1','2','3','4'};
	char password2[17] = {"1234123412341234"};
	char _s[150]={0};
	timeout = TIMEOUT_PASSWORD;
	while((timeout > 0) && (resposta == 0 ) && aux<150){
		if(caracteres_disponiveis() > 0)
			_s[aux++] = ler_caracter();
		if(strstr(_s,password2) != NULL)
			resposta = 1;
		//TODO ação caso não seja evento de conexão
		//if(strstr(_s,DISCONNECTED_MESSAGE) != NULL)
			//resposta == 2;
	}
	if(resposta == 0){
		putStringUart("WRONG PASSWORD!\r\n");
	}
	else if (resposta == 1){
		putStringUart("\r\nOK PASSWORD!\r\n");
		// TODO
		//enviar_dados_gps();
		delay_ms(100);	//100ms
		UARTCharPut(UART3_BASE, BREAK_CONNECTION_CARACTER);
	}
	else if (resposta == 2){
		delay_ms(100);	//100ms
		return; //não faz nada
	}

}

int main(void){

	//unsigned char _s[100], tamanho_mensagem=0, _c;
	setup();
	debugUart("Programa iniciado!\r\n");
	while(1){
		// Verifica em background se tem alguma mensagem para ser lida
		if(connection_updated == 1){
			debugUart("% recebido!\r\n");
			receive_password();
			connection_updated = 0;
		}
	}
}

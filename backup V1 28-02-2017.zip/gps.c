#include "gps.h"
#include <stdio.h>
#include <string.h>

Data samples[N_SAMPLES_GPS];
unsigned char sample_position=0;



unsigned char gps_buffer[GPS_BUFFER_SIZE], gps_posicao=0, ultima_pos_lida=0;

void delay_ms_gps(unsigned int time_ms){
	unsigned int i;
	for(i=0; i < time_ms; i++)
		__delay_cycles(120000);	// delay de 1ms, assumindo clock_frequency = 120MHz
}

void salvar_caracter_gps(unsigned char _c){
	/*
		retorno:
		1 = salvo com sucesso
		2 = caracter de teste encontrado e nÃ£o salvo
	 */

	gps_buffer[gps_posicao] = _c;
	gps_posicao++;
	if(gps_posicao==GPS_BUFFER_SIZE)
		gps_posicao=0;

}

unsigned int caracteres_disponiveis_gps(void){
	if(gps_posicao>=ultima_pos_lida)
		return (gps_posicao-ultima_pos_lida);
	else
		return (GPS_BUFFER_SIZE + gps_posicao - ultima_pos_lida);
}

unsigned char ler_caracter_gps(){
	unsigned char _c = gps_buffer[ultima_pos_lida];
	if(caracteres_disponiveis_gps() > 0)
		ultima_pos_lida++;
	if(ultima_pos_lida == GPS_BUFFER_SIZE)
		ultima_pos_lida = 0;
	return _c;
}
void gps_on(void){
	//TODO implementar
}

void gps_off(void){
	//TODO
}

void gps_update(void){
	char * _p = NULL;
	char _s[200]={0},
			hora_min_seg[7],dia_mes_ano[7],
			latitude[9],latitude_NS[2],
			longitude[9],longitude_EW[2],
			velocidade[10],
			validade_dados[2];
	int aux=0;
	//liga UART para coletar dados
	gps_on();
	//espera 2s para ter ao menos 1 amostra
	delay_ms_gps(2000);
	//desliga uart para evitar interrup��es desnecessarias
	gps_off();
	//Filtra posi��es e salva no struct
	while(caracteres_disponiveis_gps() > 0)
		_s[aux++] = ler_caracter_gps();
	_p = strstr(_s,GPS_PREFIX);
	if(_p != NULL){
		// utilizar sscanf para retirar os dados pertinentes
		sscanf(_s,"$GPRMC,%s,%s,%s,%s,%s,%s,%s,%*s,%s,%*s,%*s\r\n",
				hora_min_seg,validade_dados,
				latitude,latitude_NS,
				longitude,longitude_EW,
				velocidade,dia_mes_ano);
		if (strstr(validade_dados,"V") != NULL){ // V = void
			//descarta aquisi��o
		}
		else if(strstr(validade_dados, "A") != NULL){ // A = active
			// hora minuto segundo
			strncpy(samples[sample_position].hora, hora_min_seg, 2);
			strncpy(samples[sample_position].minuto, &(hora_min_seg[2]), 2);
			strncpy(samples[sample_position].segundo, &(hora_min_seg[4]), 2);
			// dia mes ano
			strncpy(samples[sample_position].dia, dia_mes_ano, 2);
			strncpy(samples[sample_position].mes, &(dia_mes_ano[2]), 2);
			strncpy(samples[sample_position].ano, &(dia_mes_ano[4]), 2);
			// velocidade
			strncpy(samples[sample_position].velocidade, velocidade, 9);
			// latidude e longitude
			// TODO: fazer aquisi��o das LAT e LONG
			// aponta para proxima struct
			sample_position++;
			if(sample_position == N_SAMPLES_GPS)
				sample_position=0;
		}

	}

}




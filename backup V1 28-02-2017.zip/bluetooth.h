#ifndef _BLUETOOTH_H_
#define _BLUETOOTH_H_



#define TIMEOUT_TIME 			8000 // em milisegundos
#define WAIT_TIME 				500 // em milisegundos
#define INQUIRY_TIME 			3 // em segundos
#define INQUIRY_DONE_RESPONSE 	'Inquiry Done'
#define NONE_BT_FOUND 			'No Devices Found'
#define MAC_ESCRAVO_TESTE 00066668365B

unsigned char check_connection(void);
unsigned char enter_AT_command_mode(void);
unsigned char enter_Data_mode(void);
void setup_BT_module(void);
void wait(unsigned int time_ms);
void ler_buffer_uart(unsigned char * _s);

#endif //_BLUETOOTH_H_

#ifndef _GPS_H_
#define _GPS_H_

#define GPS_BUFFER_SIZE 500
#define N_SAMPLES_GPS 5
#define GPS_PREFIX "$GPRMC,"

typedef struct Data{
	char latitude[13], longitude[13];
	char dia[3],mes[3],ano[5],
			hora[3],minuto[3],segundo[3];
	char velocidade[10];
}Data;



void gps_update(void);
void salvar_caracter_gps(unsigned char _c);



#endif

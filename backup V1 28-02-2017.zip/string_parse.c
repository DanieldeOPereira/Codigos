#include "string_parse.h"
#include <stdio.h>
#include <stdint.h>

// Trata as strings recebidas pelo modulo BT
unsigned char string_parser(unsigned char * _string, unsigned char modo, unsigned char * aux){
	
	/*
	Casos para cobrir:
	-Inquiry completo
	-Comparar MAC do inquiry com um cadastrado
	-Strings vindas de comandos AT do modulo BT
	-Checar senha correta
	*/
	
	/*
		0 = compara _string com aux, retorna 1 para igual ou 0 para diferente
		1 = checar inquiry
		2 = 
		3 = 
	*/
	
	switch(modo){
		case 0:
			if(strcmp(_string,aux) == 0)
				return 1;
			else
				return 0;
		break;
		
	}
}

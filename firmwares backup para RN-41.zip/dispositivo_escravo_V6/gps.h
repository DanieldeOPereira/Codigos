#ifndef _GPS_H_
#define _GPS_H_

#define GPS_BUFFER_SIZE 500
#define N_SAMPLES_GPS 5
#define GPS_PREFIX "$GPRMC,"
#define DISCONNECTED_MESSAGE "DISCONNECT"
#define REBOOT_MESSAGE "Reboot"
//#define GPS_UART_BASE UART7_BASE
//#define ECHO 0 // 1 = on, 0 = off

#define MAX_GPS_DATA 68*5

typedef struct Data{
	char latitude[14], longitude[14];
	char dia[3],mes[3],ano[3],
			hora[3],minuto[3],segundo[3];
	char velocidade[6];
	char dado_valido[2];
}Data;



unsigned char gps_update(unsigned char sample_number);
void salvar_caracter_gps(unsigned char _c);
void setup_gps(void);
void gps_string_info(char * _s);




#endif

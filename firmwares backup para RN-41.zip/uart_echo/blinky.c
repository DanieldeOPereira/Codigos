#include <stdint.h>
#include <stdbool.h>
#include "inc/tm4c1294ncpdt.h"
#include "inc/hw_types.h"
#include "inc/hw_ints.h"
#include "inc/hw_types.h"
#include "inc/hw_memmap.h"

#include "driverlib/rom.h"
#include "driverlib/rom_map.h"
#include <stdint.h>
#include <stdbool.h>

#include "driverlib/gpio.h"
#include "driverlib/sysctl.h"
#include "driverlib/pin_map.h"
#include "driverlib/interrupt.h"
#include "driverlib/timer.h"

#include "driverlib/pwm.h"
#include "driverlib/uart.h"

#include "inc/hw_gpio.h"


//*****************************************************************************
//
//! \addtogroup example_list
//! <h1>Blinky (blinky)</h1>
//!
//! A very simple example that blinks the on-board LED.
//
//*****************************************************************************

//*****************************************************************************
//
// Blink the on-board LED.
//
//*****************************************************************************
void uart3_interrupt(void)
{
	unsigned char _c;
	unsigned long ulStatus = UARTIntStatus(UART3_BASE, true);
	UARTIntClear(UART3_BASE, ulStatus);

	while(UARTCharsAvail(UART3_BASE))
	{
		_c = UARTCharGetNonBlocking(UART3_BASE);
		while (UARTBusy(UART0_BASE));
		UARTCharPutNonBlocking(UART0_BASE, _c);
	}
}

void uart0_interrupt(void)
{
	unsigned char _c;
	unsigned long ulStatus = UARTIntStatus(UART0_BASE, true);
	UARTIntClear(UART0_BASE, ulStatus);

	while(UARTCharsAvail(UART0_BASE))
	{
		_c = UARTCharGetNonBlocking(UART0_BASE);
		while (UARTBusy(UART3_BASE));
		UARTCharPutNonBlocking(UART3_BASE, _c);
		UARTCharPutNonBlocking(UART0_BASE, _c);
	}
}

int main(void)
{
	volatile uint32_t ui32Loop;

	int ui32SysClock = SysCtlClockFreqSet((SYSCTL_XTAL_25MHZ|SYSCTL_OSC_MAIN|SYSCTL_USE_PLL|SYSCTL_CFG_VCO_480), 120000000);

    //
    // Enable the GPIO port that is used for the on-board LED.
    //
    SysCtlPeripheralEnable(SYSCTL_PERIPH_GPION);
    SysCtlPeripheralEnable(SYSCTL_PERIPH_GPIOJ);
    SysCtlPeripheralEnable(SYSCTL_PERIPH_GPIOA);

    //UART0 module
    SysCtlPeripheralEnable(SYSCTL_PERIPH_UART0);
	SysCtlPeripheralEnable(SYSCTL_PERIPH_UART3);

    //
    // Check if the peripheral access is enabled.
    //
    while(!SysCtlPeripheralReady(SYSCTL_PERIPH_GPION));
    while(!SysCtlPeripheralReady(SYSCTL_PERIPH_GPIOJ));
    while(!SysCtlPeripheralReady(SYSCTL_PERIPH_UART0));
    while(!SysCtlPeripheralReady(SYSCTL_PERIPH_UART3));
    while(!SysCtlPeripheralReady(SYSCTL_PERIPH_GPIOA));


    // Uart3
    GPIOPinConfigure(GPIO_PA4_U3RX);
    GPIOPinConfigure(GPIO_PA5_U3TX);
    GPIOPinTypeUART(GPIO_PORTA_BASE, GPIO_PIN_4 | GPIO_PIN_5);
    UARTConfigSetExpClk(UART3_BASE, 120000000, 115200,
    		(UART_CONFIG_WLEN_8 | UART_CONFIG_STOP_ONE |
    				UART_CONFIG_PAR_NONE));
    UARTFIFODisable(UART3_BASE);
    //UARTFIFOLevelSet(UART3_BASE,UART_FIFO_TX1_8,UART_FIFO_RX2_8);
    UARTIntRegister(UART3_BASE, uart3_interrupt);
    UARTIntEnable(UART3_BASE, UART_INT_RX);

    // Uart3
    GPIOPinConfigure(GPIO_PA0_U0RX);
    GPIOPinConfigure(GPIO_PA1_U0TX);
    GPIOPinTypeUART(GPIO_PORTA_BASE, GPIO_PIN_0 | GPIO_PIN_1);
    UARTConfigSetExpClk(UART0_BASE, 120000000, 115200,
    		(UART_CONFIG_WLEN_8 | UART_CONFIG_STOP_ONE |
    				UART_CONFIG_PAR_NONE));
    UARTFIFODisable(UART0_BASE);
    //UARTFIFOLevelSet(UART3_BASE,UART_FIFO_TX1_8,UART_FIFO_RX2_8);
    UARTIntRegister(UART0_BASE, uart0_interrupt);
    UARTIntEnable(UART0_BASE, UART_INT_RX);



    while(1)
    {
    }
}

#ifndef _BT_TEST_H_
#define _BT_TEST_H_

#define INQUIRY_TIMEOUT 7000

unsigned char inquiry_process(unsigned char * resposta, unsigned char inquiry_duration);
void setup_BT(void);

#endif

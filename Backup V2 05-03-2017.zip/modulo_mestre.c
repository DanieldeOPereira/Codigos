/*
		Modulo BT fixo (mestre)

		Especificações:
		-Invisivel para Inquiry
		-Varre os dispositivos visivels e verifica se o MAC bate com algum conhecido
		-Ao encontrar algum MAC cadastrado, tenta conectar
		-Se conexão é feita com sucesso, manda uma sequencia de chars (senha) e espera receber dados de GPS
		-Salva em um arquivo de LOG
		-Exporta/deixa acessivel de alguma maneira os dados via server HTTP
*/

/*
	Pendencias:
	-Setup
	-Definir o que será colocado no timer, além do inquiry
	-Definir o que é necessario configurar manualmente no modulo BT
	-string_parser
	-Listar comandos necessarios no modulo BT

	FAZER UMA BIBLIOTECA PROPIA PARA O BT E GPS
*/

#include "uart.h"
#include "bluetooth.h"
#include "string_parse.h"
#include "stdio.h"
#include "inc/tm4c1294ncpdt.h"
#include "inc/hw_types.h"
#include "inc/hw_ints.h"
#include "inc/hw_types.h"
#include "inc/hw_memmap.h"

#include "driverlib/rom.h"
#include "driverlib/rom_map.h"
#include <stdint.h>
#include <stdbool.h>


#include "driverlib/gpio.h"
#include "driverlib/sysctl.h"
#include "driverlib/pin_map.h"
#include "driverlib/interrupt.h"
#include "driverlib/timer.h"

#include "driverlib/pwm.h"
#include "driverlib/uart.h"

#include "inc/hw_gpio.h"

#define TEST_CONNECTION_CARACTER '?'
#define MAC_ESCRAVO_TESTE 00066668365B
#define SENHA_ESCRAVO_TESTE 1234123412341234
#define INQUIRY_FREQ 10 // em segundos
#define ECHO 1 // 1 = on, 0 = off
#define CONNECT 0



/*  Global control variables  */
volatile unsigned char isBusy=0; // 0 = not busy, 1 = busy
volatile unsigned char lastActivity=0; // 0 = just started, need to setup module
volatile unsigned char stringPronta=0; // 0 = não esta pronta, 1 = esta pronta
volatile unsigned char timeoutCounter=0;
volatile unsigned char device_address[5*13] = {0};




// Não definido 100%
// Futuramente ira fazer Inquiry automatico e checar se algum dispositivo conhecido esta presente
void timer1_interrupt(void){
	TimerIntClear(TIMER0_BASE, TIMER_TIMA_TIMEOUT);
	unsigned char _s[100], number_devices;
	if(isBusy == 0){
		isBusy = 1;
		number_devices = inquiry_scan(INQUIRY_TIME, &timeoutCounter, device_address);
		isBusy = 0;
	}
}

// timeout function, 10hz frequency
void timer2_interrupt(void){
	TimerIntClear(TIMER1_BASE, TIMER_TIMA_TIMEOUT);
	if(timeout > 0 )
		timeout-= 100; // -100 milisegundos
}

void uart0_interrupt(void)
{
	unsigned char _c;
	unsigned long ulStatus = UARTIntStatus(UART0_BASE, true);
	UARTIntClear(UART0_BASE, ulStatus);

	while(UARTCharsAvail(UART0_BASE))
	{
		_c = UARTCharGet(UART0_BASE);
		while (UARTBusy(UART3_BASE));
		UARTCharPut(UART3_BASE, _c);
		UARTCharPut(UART0_BASE, _c);
	}
}

//Handles BT strings and detect \n (end of line)
void uart3_interrupt(void){
	/*
		Comportamentos esperados:
		-Detecta \n para saber o fim de linha e chamar função de tratamento
		-Quando receber '+' responder '+' para confirmar conexão
	*/

	//Variavel auxiliar
	unsigned char _c;
	// Pega o valor das flags de interrpção da UART3
	unsigned long ulStatus = UARTIntStatus(UART3_BASE, true);
	// Limpa flag de interrupção
	UARTIntClear(UART3_BASE, ulStatus);

	while(UARTCharsAvail(UART3_BASE))
	{
		_c = UARTCharGet(UART3_BASE);

		// Se echo = 1, replica tudo para UART de debug
		if(ECHO==1)
		UARTCharPut(UART0_BASE, _c);

		if(salvar_caracter(_c,TEST_CONNECTION_CARACTER) == 2)
		{
			UARTCharPut(UART3_BASE, _c);
			UARTCharPut(UART3_BASE, '\n');
		}
		if( _c == '\n' )
			stringPronta=1;
	}

}

void setup(void){
	//Setup clock
	SysCtlClockFreqSet((SYSCTL_XTAL_25MHZ|SYSCTL_OSC_MAIN|SYSCTL_USE_PLL|SYSCTL_CFG_VCO_480), 120000000);

	//Setup HTTP server

	//Setup UART3 at 115200, connected to RN-41 bluetooth device
    GPIOPinConfigure(GPIO_PA4_U3RX);
    GPIOPinConfigure(GPIO_PA5_U3TX);
    GPIOPinTypeUART(GPIO_PORTA_BASE, GPIO_PIN_4 | GPIO_PIN_5);
    UARTConfigSetExpClk(UART3_BASE, 120000000, 115200,
    		(UART_CONFIG_WLEN_8 | UART_CONFIG_STOP_ONE |
    				UART_CONFIG_PAR_NONE));
    UARTFIFODisable(UART3_BASE);
    //UARTFIFOLevelSet(UART3_BASE,UART_FIFO_TX1_8,UART_FIFO_RX2_8);
    UARTIntRegister(UART3_BASE, uart3_interrupt);
    UARTIntEnable(UART3_BASE, UART_INT_RX);

	//Setup UART0 at 9600 for debug (echo needs to be 1)
    GPIOPinConfigure(GPIO_PA0_U0RX);
    GPIOPinConfigure(GPIO_PA1_U0TX);
    GPIOPinTypeUART(GPIO_PORTA_BASE, GPIO_PIN_0 | GPIO_PIN_1);
    UARTConfigSetExpClk(UART0_BASE, 120000000, 115200,
    		(UART_CONFIG_WLEN_8 | UART_CONFIG_STOP_ONE |
    				UART_CONFIG_PAR_NONE));
    UARTFIFODisable(UART0_BASE);
    //UARTFIFOLevelSet(UART3_BASE,UART_FIFO_TX1_8,UART_FIFO_RX2_8);
    //UARTIntRegister(UART0_BASE, uart0_interrupt);
    //UARTIntEnable(UART0_BASE, UART_INT_RX);

	//Setup timers to control the firmware
	//Timer0 configuration
	TimerConfigure(TIMER0_BASE, TIMER_CFG_PERIODIC);//configura timer0 para onda completa
	TimerLoadSet(TIMER0_BASE, TIMER_A, INQUIRY_FREQ*120000000);//configura o timerA para um periodo de (1 * INQUIRY_FREQ) hz
	IntRegister(INT_TIMER0A, timer1_interrupt);//associa a interrupção do timer0_A a função "timer1_interrupt"
	IntEnable(INT_TIMER0A);								//habilita o timer0_A
	TimerIntEnable(TIMER0_BASE, TIMER_TIMA_TIMEOUT);
	TimerEnable(TIMER0_BASE, TIMER_A);
	//IntMasterEnable();							//habilita todas interrupções
	
	//Timer1 configuration
	TimerConfigure(TIMER1_BASE, TIMER_CFG_PERIODIC);//configura timer1 para onda completa
	TimerLoadSet(TIMER1_BASE, TIMER_A, 12000000);//configura o timerA para um periodo de 10hz
	IntRegister(INT_TIMER1A, timer2_interrupt);//associa a interrupção do timer1_A a função "timer2_interrupt"
	IntEnable(INT_TIMER1A);								//habilita o timer1_A
	TimerIntEnable(TIMER1_BASE, TIMER_TIMA_TIMEOUT);
	TimerEnable(TIMER1_BASE, TIMER_A);
	
	
	
	IntMasterEnable();							//habilita todas interrupções

}

int main(void){
	//unsigned char _s[100], tamanho_mensagem=0;
	setup();

	while(1){
		// Verifica em background se tem alguma mensagem para ser lida
//		if(stringPronta == 1){
//			tamanho_mensagem=0;
//			while(caracteres_disponiveis > 0)
//			{
//				_s[tamanho_mensagem] = ler_caracter();
//				tamanho_mensagem++;
//			}
//			_s[tamanho_mensagem] = '\n';
//			string_parser(_s);
//		}
	}
}

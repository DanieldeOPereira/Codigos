#ifndef _UART_H_
#define _UART_H_

#define UART_BUFFER_SIZE 1000

unsigned int caracteres_disponiveis();
unsigned char salvar_caracter(unsigned char _c, unsigned char test_caracter);
unsigned char ler_caracter(void);
void putStringUart(unsigned char * _s);
void debugUart(unsigned char * _s);

#endif // _UART_H_

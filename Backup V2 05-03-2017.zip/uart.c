#include "uart.h"
#include "inc/hw_memmap.h"
#include <stdbool.h>
#include <stdint.h>
#include "driverlib/uart.h"
#include <stdio.h>
#include <string.h>


unsigned char uartBuffer[UART_BUFFER_SIZE]={0};
unsigned char uartPosition=0, readedPosition=0;

unsigned int caracteres_disponiveis(void){
	if(uartPosition>=readedPosition)
		return (uartPosition-readedPosition);
	else
		return (UART_BUFFER_SIZE + uartPosition - readedPosition);
}

unsigned char salvar_caracter(unsigned char _c, unsigned char test_caracter){
	/*
		retorno:
		1 = salvo com sucesso
		2 = caracter de teste encontrado e nÃƒÂ£o salvo
	*/
	if(_c == test_caracter)
		return 2;
	else{
		uartBuffer[uartPosition] = _c;
		uartPosition++;
		if(uartPosition==UART_BUFFER_SIZE)
			uartPosition=0;
		return 1;
	}
}

unsigned char ler_caracter(void){
	unsigned char _c = uartBuffer[readedPosition];
	if(caracteres_disponiveis > 0){
		readedPosition++;
		if(readedPosition == UART_BUFFER_SIZE)
			readedPosition = 0;
		return _c;
	}
	else
		return 255; //falha
}

void putStringUart(unsigned char * _s){
	unsigned int i;
	for(i=0; i< strlen(_s); i++)
		UARTCharPut(UART3_BASE, _s[i]);
}

void debugUart( unsigned char * _s){
	unsigned int i;
		for(i=0; i< strlen(_s); i++)
			UARTCharPut(UART0_BASE, _s[i]);
//	while(*_s != '\0')
//			UARTCharPut(UART0_BASE, *_s);
}

#ifndef _STRING_PARSER_H_
#define _STRING_PARSER_H_

#include <stdint.h>
#include <stdbool.h>

unsigned char string_parser(unsigned char * _string, unsigned char modo, unsigned char * aux);

#endif

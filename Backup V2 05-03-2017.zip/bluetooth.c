#include "bluetooth.h"
#include "string_parse.h"
#include "driverlib/uart.h"
#include "inc/hw_memmap.h"
#include <stdbool.h>
#include <stdint.h>
#include "uart.h"
#include "string_parse.h"
#include <stdio.h>

unsigned char check_connection(void){
	/*
	  retorno:
	  1 = sucesso
	  0 = falha
	*/
	unsigned char _s[200];
	
	enter_AT_command_mode();
	UARTCharPut(UART3_BASE,'L');
	UARTCharPut(UART3_BASE,'\n');
	wait(WAIT_TIME);
	ler_buffer_uart(_s);
	//string_parser(_s);
	
	return 0;
}

unsigned char enter_AT_command_mode(void){
	/*
	  retorno:
	  1 = sucesso
	  0 = falha
	*/
	unsigned char _s[100] = {0} ;
	//envia comando para entrar no modo AT
	UARTCharPut(UART3_BASE, '$');
	UARTCharPut(UART3_BASE, '$');
	UARTCharPut(UART3_BASE, '$');
	
	//checar resposta
	wait(WAIT_TIME);
	ler_buffer_uart(_s);
	//string_parse();

	return 0;
}

unsigned char enter_Data_mode(void){
	/*
	  retorno:
	  1 = sucesso
	  0 = falha
	*/
	
	UARTCharPut(UART3_BASE, '-');
	UARTCharPut(UART3_BASE, '-');
	UARTCharPut(UART3_BASE, '-');
	UARTCharPut(UART3_BASE, '\n');
	//checar resposta

	// dar retorno
	return 0;
}

void setup_BT_module(void){
	/* 
	colocar configura��es necessarias ao bootar
	-setar '%' como break connection (SO,%\n\r)
	*/
	
}

void wait(unsigned int time_ms){
	unsigned int i;
	for(i=0; i<time_ms; i++)
	__delay_cycles(120000);	// assumindo clock_frequency = 120MHz
}

void ler_buffer_uart(unsigned char * _s){
	unsigned char _c=0, aux=0;
	while((caracteres_disponiveis() > 0) && (_c != '\n')){
		_s[aux++] = ler_caracter();
	}
	if(_c != '\n')
		_s[aux] = '\n';
}

unsigned char inquiry_scan(unsigned char scan_time, volatile unsigned char * timeout, volatile unsigned char * enderecos){
	unsigned char aux=0, resposta= 0, endere�o, _BTadress[14];
	unsigned char * _p;
	char _s[300]={0};
	
	// Entrar modo AT
	enter_AT_command_mode();
	
	// Esvazia enderecos na lista de enderecos
	//strncpy(enderecos,0,sizeof(enderecos));
	enderecos[0] = '\0';
	
	// Manda Inquiry com tempo informado
	sprintf(_s,"I,%c\n",scan_time);
	while( _s[aux] != '\n')
		UARTCharPut(UART3_BASE,_s[aux++]);
	
	// Esvazia a string _s
	aux = 0;
	while(aux<300)
		_s[aux++] = 0;
	
	// Espera ate achar
	aux = 0;
	*timeout = TIMEOUT_TIME / 100;
	while(( resposta == 0) && (*timeout > 0)){
		if((caracteres_disponiveis() > 0) && (aux<300))
			_s[aux++] = ler_caracter();
		if( strstr(_s, INQUIRY_DONE_RESPONSE) != NULL )
			resposta = 1;
	}
	// Se recebeu INQUIRY_DONE_RESPONSE
	if(resposta == 1){
		//
		if(strstr(_s, NONE_BT_FOUND) != NULL )
			return 0;
		else{
			if(strstr(_s, MAC_ESCRAVO_TESTE) != NULL )
				strcpy(enderecos,MAC_ESCRAVO_TESTE);
		}
	}	
	else // Se n�o recebeu resposta INQUIRY_DONE_RESPONSE		
		return -1; //timeout	
	
}

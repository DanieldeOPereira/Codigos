#include <stdint.h>
#include <stdbool.h>
#include <stdio.h>
#include <string.h>
#include "gps.h"
#include "inc/hw_memmap.h"
#include "driverlib/uart.h"
#include "uart.h"


extern volatile Data samples[N_SAMPLES_GPS];
//extern volatile unsigned char sample_position;
unsigned char contador_bolado = 0;

extern volatile unsigned int timeout;
char gps_buffer[GPS_BUFFER_SIZE]={0};
volatile unsigned int gps_posicao=0, ultima_pos_lida=0;

volatile unsigned char gps_save_flag = 0;


void gps_off(void){
	// Desliga interrupção
	//UARTIntDisable(UART7_BASE, UART_INT_RX);
	//UARTDisable(UART7_BASE);
	gps_save_flag = 0;
}

void flush_gps_buffer(){
//	unsigned int i;
//	for(i=0;i<GPS_BUFFER_SIZE;i++)
//		gps_buffer[i]=0;
	ultima_pos_lida = gps_posicao;
}

void flush_gps_buffer_especifico(unsigned char _posicao){
	unsigned char i = _posicao;
	//if(_posicao < N_SAMPLES_GPS)
	{
		memset(samples[i].ano,0,3);
		memset(samples[i].mes,0,3);
		memset(samples[i].dia,0,3);
		memset(samples[i].hora,0,3);
		memset(samples[i].minuto,0,3);
		memset(samples[i].segundo,0,3);
		memset(samples[i].latitude,0,14);
		memset(samples[i].longitude,0,14);
		memset(samples[i].velocidade,0,6);
	}
}

void setup_gps(void){
	unsigned int i=0;
	gps_off();

	for(i=0;i<N_SAMPLES_GPS;i++){
		strcpy(samples[i].dado_valido,"0"); //0 = não-valido, 1 = valido
		memset(samples[i].ano,0,sizeof(samples[i].ano));
		memset(samples[i].mes,0,sizeof(samples[i].mes));
		memset(samples[i].dia,0,sizeof(samples[i].dia));
		memset(samples[i].hora,0,sizeof(samples[i].hora));
		memset(samples[i].minuto,0,sizeof(samples[i].minuto));
		memset(samples[i].segundo,0,sizeof(samples[i].segundo));
		memset(samples[i].latitude,0,sizeof(samples[i].latitude));
		memset(samples[i].longitude,0,sizeof(samples[i].longitude));
		memset(samples[i].velocidade,0,sizeof(samples[i].velocidade));
	}

}

void delay_ms_gps(unsigned int time_ms){
	unsigned int i;
	for(i=0; i < time_ms; i++)
		__delay_cycles(120000);	// delay de 1ms, assumindo clock_frequency = 120MHz
}

void salvar_caracter_gps(unsigned char _c){

	gps_buffer[gps_posicao] = _c;
	gps_posicao++;
	if(gps_posicao==GPS_BUFFER_SIZE)
		gps_posicao=0;

}

unsigned int caracteres_disponiveis_gps(void){
	if(gps_posicao>=ultima_pos_lida)
		return (gps_posicao-ultima_pos_lida);
	else
		return (GPS_BUFFER_SIZE + gps_posicao - ultima_pos_lida);
}

unsigned char ler_caracter_gps(){
	unsigned char _c = gps_buffer[ultima_pos_lida];
	if(caracteres_disponiveis_gps() > 0)
		ultima_pos_lida++;
	if(ultima_pos_lida == GPS_BUFFER_SIZE)
		ultima_pos_lida = 0;
	return _c;
}

void gps_on(void){
	// Esvaziar dados antigos
//	while(UARTCharsAvail(UART7_BASE))
//			UARTCharGet(UART7_BASE);
//	// Liga interrupção
//	UARTIntEnable(UART7_BASE, UART_INT_RX);
	//flush_gps_buffer();
	//UARTEnable(UART7_BASE);
	gps_save_flag = 1;
}

unsigned char gps_update(unsigned char sample_number){
	char * _p = NULL;
	char _s[300]={0},
			hora_min_seg[7]={0},dia_mes_ano[7]={0},
			latitude[11]={0},latitude_NS[2]={0},
			longitude[12]={0},longitude_EW[2]={0},
			velocidade[10]={0},
			validade_dados[2]={0};
	char _printf[300] = {0};
	unsigned int aux=0,aux2;
//	memset(_s,0,298);
	//liga UART para coletar dados
	gps_on();
	timeout = 3000;
	while((timeout > 0) && (aux < 300)){
		while((caracteres_disponiveis_gps() > 0) && (aux < 300))
			_s[aux++] = ler_caracter_gps();
			if( strstr(_s,GPS_PREFIX) != NULL ){
				_p = strstr(_s,GPS_PREFIX);
				while((strstr(_p,"*") == NULL) && (aux < 300)){
					while((caracteres_disponiveis_gps() > 0) && (aux < 300))
						_s[aux++] = ler_caracter_gps();
				}
				gps_off();
				timeout = 0;
			}
	}
	//desliga uart para evitar interrupções desnecessarias
	gps_off();

	//_p = strstr(gps_buffer,GPS_PREFIX);
	_p = strstr(_s,GPS_PREFIX);


	if(_p != NULL){
//		while(_p[aux] != '\n' && aux < 100){
//				_s[aux] = *_p;
//				aux++;
//				_p++;
//		}
//		_p++;
//		while(_p[aux] != '\n' && aux < 100){
//			_s[aux] = *_p;
//			aux++;
//			_p++;
//		}
		// utilizar sscanf para retirar os dados pertinentes


		sscanf(_p,"%*[^,],%[^,],%[^,],%[^,],%[^,],%[^,],%[^,],%[^,],",
				hora_min_seg,validade_dados,
				latitude,latitude_NS,
				longitude,longitude_EW,
				velocidade);
		aux = 0;
		aux2 = 0;
		while((aux<9)&& (aux2 < 100)){
			if(_p[aux2] == ',')
				aux++;
			aux2++;
		}
		if(aux==9){
			sscanf(&(_p[aux2]),"%[^,],",dia_mes_ano);
		}

		if (strstr(validade_dados,"V") != NULL){ // V = void
			//descarta aquisição
			debugUart("GPS nao fixado!\r\n\r\n");
			return 0;
		}
		else if(strstr(validade_dados, "A") != NULL){ // A = active

			flush_gps_buffer_especifico(sample_number);

			// Diz que a amostra é valida
			//strcpy(samples[sample_position].dado_valido,"1");
			samples[sample_number].dado_valido[0] = '1';
			// hora minuto segundo
			strncpy(samples[sample_number].hora, hora_min_seg, 2);
			strncpy(samples[sample_number].minuto, &(hora_min_seg[2]), 2);
			strncpy(samples[sample_number].segundo, &(hora_min_seg[4]), 2);
			// dia mes ano
			strncpy(samples[sample_number].dia, dia_mes_ano, 2);
			strncpy(samples[sample_number].mes, &(dia_mes_ano[2]), 2);
			strncpy(samples[sample_number].ano, &(dia_mes_ano[4]), 2);
			// velocidade
			strncpy(samples[sample_number].velocidade, velocidade, 9);
			// latidude e longitude
			strncpy(samples[sample_number].latitude,latitude,10);
			strncat(samples[sample_number].latitude,latitude_NS,1);
			strncpy(samples[sample_number].longitude,longitude,11);
			strncat(samples[sample_number].longitude,longitude_EW,1);
			// aponta para proxima struct
			//sample_position++;

			debugUart("\r\nDados GPS salvos com sucesso!\r\n");
//
			sprintf(_printf,"Data: %s / %s / %s\r\n", samples[sample_number].dia , samples[sample_number].mes , samples[sample_number].ano);
			debugUart(_printf); // dia, mes, ano
			sprintf(_printf,"%s : %s : %s\r\n",samples[sample_number].hora,samples[sample_number].minuto,samples[sample_number].segundo);
			debugUart(_printf); // hora, minuto, segundo
			sprintf(_printf,"Velocidade: %s knots\r\n",samples[sample_number].velocidade);
			debugUart(_printf); // velocidade
			sprintf(_printf,"Lat: %s , Long: %s \r\n\r\n",samples[sample_number].latitude,samples[sample_number].longitude);
			debugUart(_printf); // lat, long

//			sample_position++;
//			if(sample_position == N_SAMPLES_GPS)
//				sample_position=0;
//			contador_bolado++;
//			if(contador_bolado>=5)
//				contador_bolado=0;

			flush_gps_buffer();
			return 1;
		}
		else{
			debugUart("Nenhuma string compativel encontrada!\r\n\r\n");
			return 0;
		}
	}
	else{
		debugUart("Nenhuma string compativel encontrada ou timeout!\r\n\r\n");
		//debugUart(_s);
		flush_gps_buffer();
		return 0;
	}
	return 0;
}

void gps_string_info (char * _s){
	unsigned int i;

	// escreve em _s uma string formatada com data, hora e LatLong
	//_s[0] = '<';
	strcpy(_s,"<");
	for(i=0; i< N_SAMPLES_GPS; i++){
		//if(strstr(samples[i].dado_valido,"V") != NULL){
		//if(samples[i].dado_valido[0] == '1')
		{
			strcat(_s,"(");
			strcat(_s,"TIME=");
			strcat(_s,samples[i].hora);
			strcat(_s,samples[i].minuto);
			strcat(_s,samples[i].segundo);
			strcat(_s,",LAT=");
			strcat(_s,samples[i].latitude);
			strcat(_s,",LONG=");
			strcat(_s,samples[i].longitude);
			strcat(_s,",SPEED=");
			strcat(_s,samples[i].velocidade);
			strcat(_s,")");
		}
	}
	strcat(_s,">\r\n");
}


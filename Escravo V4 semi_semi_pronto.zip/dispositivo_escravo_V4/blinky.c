/*
		Modulo BT movel (escravo)
		- Fica visivel para Inquiry e conex�o
		- Ao ser conectado, espera uma senha de x caracteres
		- Se senha certa, envia dados de GPS(a definir) e fecha conex�o
		- Se errada, fecha a conex�o
		- Ser� passivo na comunica��o do BT
*/

/*
	Pendencias:
	-Setup
	-Definir o que � necessario configurar manualmente no modulo BT
	-string_parser
	-Listar comandos necessarios no modulo BT
	-Fun��o de parser do GPS

	FAZER UMA BIBLIOTECA PROPIA PARA O BT E GPS
*/

#include "uart.h"
//#include "bluetooth.h"
//#include "string_parse.h"
#include "gps.h"

//#include "uart.h"
//#include "bluetooth.h"
//#include "string_parse.h"
#include "stdio.h"
#include "inc/tm4c1294ncpdt.h"
#include "inc/hw_types.h"
//#include "inc/hw_ints.h"
#include "inc/hw_types.h"
#include "inc/hw_memmap.h"

#include "driverlib/rom.h"
#include "driverlib/rom_map.h"
#include <stdint.h>
#include <stdbool.h>
#include <stdio.h>
#include <string.h>


#include "driverlib/gpio.h"
#include "driverlib/sysctl.h"
#include "driverlib/pin_map.h"
#include "driverlib/interrupt.h"
#include "driverlib/timer.h"

#include "driverlib/pwm.h"
#include "driverlib/uart.h"

#include "inc/hw_gpio.h"

#define BREAK_CONNECTION_CARACTER '%'
#define TEST_CONNECTION_CARACTER '+'
#define CONNECT 0
#define ECHO 2 // 1 = on, 0 = off
#define TIMEOUT_PASSWORD 5000 // em milisegundos




/*  Global control variables  */
volatile unsigned char isBusy=0; // 0 = not busy, 1 = busy
volatile unsigned char lastActivity=0; // 0 = just started, need to setup module
volatile unsigned char stringPronta=0; // 0 = n�o esta pronta, 1 = esta pronta
volatile unsigned char connection_updated = 0; // 0 = nenhum evento de conex�o pendente, 1 = recebeu %
volatile unsigned int timeout = 0;


volatile unsigned char gps_update_flag = 0;
extern volatile unsigned char gps_save_flag;
volatile unsigned char sample_position = 0;
volatile Data samples[N_SAMPLES_GPS];

void delay_ms(unsigned int time_ms){
	unsigned int i;
	for(i=0; i < time_ms; i++)
		__delay_cycles(120000);	// delay de 1ms, assumindo clock_frequency = 120MHz
}

// N�o definido 100%
// Coleta e salva periodicamente dados de GPS
// 0,1 Hz
void timer1_interrupt(void){
	TimerIntClear(TIMER0_BASE, TIMER_TIMA_TIMEOUT);
	//TODO chamar atualiza��o do gps
	gps_update_flag = 1;
}

//timeout timer interrupt
//10 hz
void timer2_interrupt(void){
	TimerIntClear(TIMER1_BASE, TIMER_TIMA_TIMEOUT);
	if(timeout > 0 )
		timeout-= 100; // -100 milisegundos
}

// debug PC -> tiva
void uart0_interrupt(void)
{
	unsigned char _c;
	unsigned long ulStatus = UARTIntStatus(UART0_BASE, true);
	UARTIntClear(UART0_BASE, ulStatus);

	while(UARTCharsAvail(UART0_BASE))
	{
		_c = UARTCharGetNonBlocking(UART0_BASE);
		while (UARTBusy(UART3_BASE));
		UARTCharPutNonBlocking(UART3_BASE, _c);
		UARTCharPutNonBlocking(UART0_BASE, _c);
	}
}

//Handles BT strings and detect \n (end of line)
void uart3_interrupt(void){
	/*
		Comportamentos esperados:
		-Detecta \n para saber o fim de linha e chamar fun��o de tratamento
		-Quando receber '*' responder '*' para confirmar conex�o
	*/

	//Variavel auxiliar
	unsigned char _c;
	// Pega o valor das flags de interrp��o da UART3
	unsigned long ulStatus = UARTIntStatus(UART3_BASE, true);
	// Limpa flag de interrup��o
	UARTIntClear(UART3_BASE, ulStatus);

	while(UARTCharsAvail(UART3_BASE))
	{
		_c = UARTCharGetNonBlocking(UART3_BASE);

		// Se echo = 1, replica tudo para UART de debug
		if(ECHO==1)
			UARTCharPutNonBlocking(UART0_BASE, _c);

		if(salvar_caracter(_c,TEST_CONNECTION_CARACTER) == 2)
		{
			UARTCharPutNonBlocking(UART3_BASE, _c);
			UARTCharPutNonBlocking(UART3_BASE, '\n');
		}
//		if( _c == '\n' )
//			stringPronta=1;
		if(_c == BREAK_CONNECTION_CARACTER){
			connection_updated = 1;
			//delay_ms(100);
		}
	}

}

void uart7_interrupt(void){
	unsigned char _c;
	unsigned long ulStatus = UARTIntStatus(UART7_BASE, true);
	UARTIntClear(UART7_BASE, ulStatus);
	UARTRxErrorClear(UART7_BASE);

	while(UARTCharsAvail(UART7_BASE))
	{
		UARTRxErrorClear(UART7_BASE);
		_c = UARTCharGetNonBlocking(UART7_BASE);
		// Se echo = 1, replica tudo para UART de debug
		if(gps_save_flag == 1){
			salvar_caracter_gps(_c);
			if(ECHO==2)
				UARTCharPutNonBlocking(UART0_BASE, _c);
		}
	}
}

void setup(void){
	//Setup clock
	SysCtlClockFreqSet((SYSCTL_XTAL_25MHZ|SYSCTL_OSC_MAIN|SYSCTL_USE_PLL|SYSCTL_CFG_VCO_480), 120000000);

	//Enable peripherals
	SysCtlPeripheralEnable(SYSCTL_PERIPH_UART3);
	SysCtlPeripheralEnable(SYSCTL_PERIPH_UART0);
	SysCtlPeripheralEnable(SYSCTL_PERIPH_UART7);
	SysCtlPeripheralEnable(SYSCTL_PERIPH_TIMER0);
	SysCtlPeripheralEnable(SYSCTL_PERIPH_TIMER1);
	SysCtlPeripheralEnable(SYSCTL_PERIPH_GPIOA);
	SysCtlPeripheralEnable(SYSCTL_PERIPH_GPIOC);

	while (!SysCtlPeripheralReady(SYSCTL_PERIPH_GPIOA));
	while (!SysCtlPeripheralReady(SYSCTL_PERIPH_GPIOC));
	while (!SysCtlPeripheralReady(SYSCTL_PERIPH_TIMER1));
	while (!SysCtlPeripheralReady(SYSCTL_PERIPH_TIMER0));
	while (!SysCtlPeripheralReady(SYSCTL_PERIPH_UART3));
	while (!SysCtlPeripheralReady(SYSCTL_PERIPH_UART0));
	while (!SysCtlPeripheralReady(SYSCTL_PERIPH_UART7));

	//Setup UART3 at 115200, connected to RN-41 bluetooth device
	GPIOPinConfigure(GPIO_PA4_U3RX);
	GPIOPinConfigure(GPIO_PA5_U3TX);
	GPIOPinTypeUART(GPIO_PORTA_BASE, GPIO_PIN_4 | GPIO_PIN_5);
	UARTConfigSetExpClk(UART3_BASE, 120000000, 115200,
			(UART_CONFIG_WLEN_8 | UART_CONFIG_STOP_ONE |
					UART_CONFIG_PAR_NONE));
	UARTFIFODisable(UART3_BASE);
	//UARTFIFOLevelSet(UART3_BASE,UART_FIFO_TX1_8,UART_FIFO_RX2_8);
	UARTIntRegister(UART3_BASE, uart3_interrupt);
	UARTIntEnable(UART3_BASE, UART_INT_RX);

	//Setup UART0 at 9600 for debug (echo needs to be 1)
	GPIOPinConfigure(GPIO_PA0_U0RX);
	GPIOPinConfigure(GPIO_PA1_U0TX);
	GPIOPinTypeUART(GPIO_PORTA_BASE, GPIO_PIN_0 | GPIO_PIN_1);
	UARTConfigSetExpClk(UART0_BASE, 120000000, 115200,
			(UART_CONFIG_WLEN_8 | UART_CONFIG_STOP_ONE |
					UART_CONFIG_PAR_NONE));
	UARTFIFODisable(UART0_BASE);
	UARTIntRegister(UART0_BASE, uart0_interrupt);
	UARTIntEnable(UART0_BASE, UART_INT_RX);

	//Setup UART7 for GPS module
	//TODO n�o esta funcionando
	GPIOPinConfigure(GPIO_PC4_U7RX);
	GPIOPinConfigure(GPIO_PC5_U7TX);
	GPIOPinTypeUART(GPIO_PORTC_BASE, GPIO_PIN_4 | GPIO_PIN_5);
	UARTConfigSetExpClk(UART7_BASE, 120000000, 9600,
			(UART_CONFIG_WLEN_8 | UART_CONFIG_STOP_ONE |
					UART_CONFIG_PAR_NONE));
	UARTFIFODisable(UART7_BASE);
	//UARTFIFOEnable(UART7_BASE);
	//UARTFIFOLevelSet(UART7_BASE, UART_FIFO_TX7_8,
	//		UART_FIFO_RX7_8);
	//UARTFIFOLevelSet
	UARTIntRegister(UART7_BASE, uart7_interrupt);
	UARTIntEnable(UART7_BASE, UART_INT_OE);
	UARTIntEnable(UART7_BASE, UART_INT_RX);
	//UARTDisable(UART7_BASE);

	//Setup timers to control the firmware
	// Timeout Timer
	//Timer1 configuration
	TimerConfigure(TIMER1_BASE, TIMER_CFG_PERIODIC);//configura timer1 para onda completa
	TimerLoadSet(TIMER1_BASE, TIMER_A, 12000000);//configura o timerA para um periodo de 10hz
	IntRegister(INT_TIMER1A, timer2_interrupt);//associa a interrup��o do timer1_A a fun��o "timer2_interrupt"
	IntEnable(INT_TIMER1A);								//habilita o timer1_A
	TimerIntEnable(TIMER1_BASE, TIMER_TIMA_TIMEOUT);
	TimerEnable(TIMER1_BASE, TIMER_A);

	//Timer0 configuration
	TimerConfigure(TIMER0_BASE, TIMER_CFG_PERIODIC);//configura timer1 para onda completa
	TimerLoadSet(TIMER0_BASE, TIMER_A, 1200000000);//configura o timerA para um periodo de 10hz
	IntRegister(INT_TIMER0A, timer1_interrupt);//associa a interrup��o do timer1_A a fun��o "timer2_interrupt"
	IntEnable(INT_TIMER0A);								//habilita o timer1_A
	TimerIntEnable(TIMER0_BASE, TIMER_TIMA_TIMEOUT);
	TimerEnable(TIMER0_BASE, TIMER_A);

}

void receive_password(void){
	unsigned char resposta = 0, aux=0;
	//char password[17] = {'1','2','3','4','1','2','3','4','1','2','3','4','1','2','3','4'};
	char password2[17] = {"1234123412341234"};
	char _s[400]={0};
	timeout = TIMEOUT_PASSWORD;
	while((timeout > 0) && (resposta == 0 ) && aux<150){
		if(caracteres_disponiveis() > 0)
			_s[aux++] = ler_caracter();
		if(strstr(_s,password2) != NULL)
			resposta = 1;
		//TODO a��o caso n�o seja evento de conex�o
		if(strstr(_s,DISCONNECTED_MESSAGE) != NULL)
			resposta = 2;
	}
	if(resposta == 0){
		putStringUart("WRONG PASSWORD!\r\n");
		debugUart("WRONG PASSWORD!\r\n");
	}
	else if (resposta == 1){
		putStringUart("\r\nOK PASSWORD!\r\n");
		debugUart("\r\nOK PASSWORD!\r\n");
		gps_string_info(_s);
		debugUart(_s);
		putStringUart(_s);
	}
	else if (resposta == 2){
		debugUart("\r\nDesconectado!\r\n");
		return; //n�o faz nada
	}
	delay_ms(500);
	UARTCharPutNonBlocking(UART3_BASE, BREAK_CONNECTION_CARACTER);
}

int main(void){
	unsigned char posicao_dados_gps = 0;
	unsigned char aux;
	//unsigned char _s[100], tamanho_mensagem=0, _c;
	setup();
	debugUart("\r\nPrograma iniciado!\r\n");
	while(1){
		// Verifica em background se tem alguma mensagem para ser lida
		if(connection_updated == 1){
			delay_ms(100);
			debugUart("% recebido!\r\n");
			receive_password();
			connection_updated = 0;
		}
		if(gps_update_flag == 1){
			delay_ms(50);
			debugUart("Atualizando gps!\r\n");
			aux = posicao_dados_gps;
			if(gps_update(aux) == 1){
				posicao_dados_gps++;
				if(posicao_dados_gps == N_SAMPLES_GPS)
					posicao_dados_gps = 0;
			}
			gps_update_flag = 0;
		}
	}
}

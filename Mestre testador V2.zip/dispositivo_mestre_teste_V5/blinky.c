/*
		Modulo BT fixo (mestre)

		Especifica��es:
		-Invisivel para Inquiry
		-Varre os dispositivos visivels e verifica se o MAC bate com algum conhecido
		-Ao encontrar algum MAC cadastrado, tenta conectar
		-Se conex�o � feita com sucesso, manda uma sequencia de chars (senha) e espera receber dados de GPS
		-Salva em um arquivo de LOG
		-Exporta/deixa acessivel de alguma maneira os dados via server HTTP
*/

/*
	Pendencias:
	-Setup
	-Definir o que ser� colocado no timer, al�m do inquiry
	-Definir o que � necessario configurar manualmente no modulo BT
	-string_parser
	-Listar comandos necessarios no modulo BT

	FAZER UMA BIBLIOTECA PROPIA PARA O BT E GPS
*/

#include "uart.h"
//#include "bluetooth.h"
//#include "string_parse.h"
#include "stdio.h"
#include "bt_mestre_teste.h"
#include "inc/tm4c1294ncpdt.h"
#include "inc/hw_types.h"
//#include "inc/hw_ints.h"
#include "inc/hw_types.h"
#include "inc/hw_memmap.h"

#include "driverlib/rom.h"
#include "driverlib/rom_map.h"
#include <stdint.h>
#include <stdbool.h>


#include "driverlib/gpio.h"
#include "driverlib/sysctl.h"
#include "driverlib/pin_map.h"
#include "driverlib/interrupt.h"
#include "driverlib/timer.h"

#include "driverlib/pwm.h"
#include "driverlib/uart.h"

#include "inc/hw_gpio.h"

#define TEST_CONNECTION_CARACTER '?'

#define INQUIRY_FREQ 10 // em segundos
#define ECHO 1 // 1 = on, 0 = off
#define CONNECT 0
#define TIVA_FREQUENCY 120000000



#include "uart.h"
//#include "bluetooth.h"
//#include "string_parse.h"
//#include "gps.h"

//#include "uart.h"
//#include "bluetooth.h"
//#include "string_parse.h"
#include "stdio.h"
#include "inc/tm4c1294ncpdt.h"
#include "inc/hw_types.h"
#include "inc/hw_memmap.h"

#include "driverlib/rom.h"
#include "driverlib/rom_map.h"
#include <stdint.h>
#include <stdbool.h>
#include <stdio.h>
#include <string.h>


#include "driverlib/gpio.h"
#include "driverlib/sysctl.h"
#include "driverlib/pin_map.h"
#include "driverlib/interrupt.h"
#include "driverlib/timer.h"

#include "driverlib/pwm.h"
#include "driverlib/uart.h"

#include "inc/hw_gpio.h"

volatile unsigned char inquiryOnGoing = 0;
volatile unsigned char isConnected = 0;
volatile unsigned char call_inquiry_flag = 0;

volatile unsigned int timeout = 0;

volatile char mac_list[20][12] = {'0'};

// Periodicamente chama seta flag de inquiry
// Chamad a cada 2s
void timer1_interrupt(void){
	TimerIntClear(TIMER0_BASE, TIMER_TIMA_TIMEOUT);
	//TODO chamar atualiza��o do gps
	call_inquiry_flag = 1;
}

//timeout timer interrupt
//10 hz
void timer2_interrupt(void){
	TimerIntClear(TIMER1_BASE, TIMER_TIMA_TIMEOUT);
	if(timeout >= 100 && timeout <= 20000 )
		timeout-= 100; // -100 milisegundos
	else
		timeout = 0;
}

// debug PC -> tiva
void uart0_interrupt(void)
{
	unsigned char _c;
	unsigned long ulStatus = UARTIntStatus(UART0_BASE, true);
	UARTIntClear(UART0_BASE, ulStatus);

	while(UARTCharsAvail(UART0_BASE))
	{
		_c = UARTCharGetNonBlocking(UART0_BASE);
		while (UARTBusy(UART3_BASE));
		UARTCharPutNonBlocking(UART3_BASE, _c);
		UARTCharPutNonBlocking(UART0_BASE, _c);
	}
}

void uart3_interrupt(void){
	/*
		Comportamentos esperados:
		-Detecta \n para saber o fim de linha e chamar fun��o de tratamento
		-Quando receber '*' responder '*' para confirmar conex�o
	*/

	//Variavel auxiliar
	unsigned char _c;
	// Pega o valor das flags de interrp��o da UART3
	unsigned long ulStatus = UARTIntStatus(UART3_BASE, true);
	// Limpa flag de interrup��o
	UARTIntClear(UART3_BASE, ulStatus);

	while(UARTCharsAvail(UART3_BASE))
	{
		UARTRxErrorClear(UART3_BASE);
		_c = UARTCharGetNonBlocking(UART3_BASE);

		// Se echo = 1, replica tudo para UART de debug
		if(ECHO==1)
			UARTCharPutNonBlocking(UART0_BASE, _c);

		salvar_caracter(_c,TEST_CONNECTION_CARACTER);
	}

}


void setup(void){
	//Setup clock
	SysCtlClockFreqSet((SYSCTL_XTAL_25MHZ|SYSCTL_OSC_MAIN|SYSCTL_USE_PLL|SYSCTL_CFG_VCO_480), TIVA_FREQUENCY);

	//Enable peripherals
	SysCtlPeripheralEnable(SYSCTL_PERIPH_UART3);
	SysCtlPeripheralEnable(SYSCTL_PERIPH_UART0);
	SysCtlPeripheralEnable(SYSCTL_PERIPH_UART7);
	SysCtlPeripheralEnable(SYSCTL_PERIPH_TIMER0);
	SysCtlPeripheralEnable(SYSCTL_PERIPH_TIMER1);
	SysCtlPeripheralEnable(SYSCTL_PERIPH_GPIOA);
	SysCtlPeripheralEnable(SYSCTL_PERIPH_GPIOC);

	while (!SysCtlPeripheralReady(SYSCTL_PERIPH_GPIOA));
	while (!SysCtlPeripheralReady(SYSCTL_PERIPH_GPIOC));
	while (!SysCtlPeripheralReady(SYSCTL_PERIPH_TIMER1));
	while (!SysCtlPeripheralReady(SYSCTL_PERIPH_TIMER0));
	while (!SysCtlPeripheralReady(SYSCTL_PERIPH_UART3));
	while (!SysCtlPeripheralReady(SYSCTL_PERIPH_UART0));
	while (!SysCtlPeripheralReady(SYSCTL_PERIPH_UART7));

	//Setup UART3 at 115200, connected to RN-41 bluetooth device
	GPIOPinConfigure(GPIO_PA4_U3RX);
	GPIOPinConfigure(GPIO_PA5_U3TX);
	GPIOPinTypeUART(GPIO_PORTA_BASE, GPIO_PIN_4 | GPIO_PIN_5);
	UARTConfigSetExpClk(UART3_BASE, 120000000, 115200,
			(UART_CONFIG_WLEN_8 | UART_CONFIG_STOP_ONE |
					UART_CONFIG_PAR_NONE));
	UARTFIFODisable(UART3_BASE);
	//UARTFIFOLevelSet(UART3_BASE,UART_FIFO_TX1_8,UART_FIFO_RX2_8);
	UARTIntRegister(UART3_BASE, uart3_interrupt);
	UARTIntEnable(UART3_BASE, UART_INT_RX);
	UARTIntEnable(UART3_BASE, UART_INT_OE);

	//Setup UART0 at 115200 for debug (echo needs to be 1)
	GPIOPinConfigure(GPIO_PA0_U0RX);
	GPIOPinConfigure(GPIO_PA1_U0TX);
	GPIOPinTypeUART(GPIO_PORTA_BASE, GPIO_PIN_0 | GPIO_PIN_1);
	UARTConfigSetExpClk(UART0_BASE, 120000000, 115200,
			(UART_CONFIG_WLEN_8 | UART_CONFIG_STOP_ONE |
					UART_CONFIG_PAR_NONE));
	UARTFIFODisable(UART0_BASE);
	UARTIntRegister(UART0_BASE, uart0_interrupt);
	UARTIntEnable(UART0_BASE, UART_INT_RX);


	//Setup timers to control the firmware
	// Timeout Timer
	//Timer1 configuration
	TimerConfigure(TIMER1_BASE, TIMER_CFG_PERIODIC);//configura timer1 para onda completa
	TimerLoadSet(TIMER1_BASE, TIMER_A, TIVA_FREQUENCY/10);//configura o timerA para um periodo de 10hz
	IntRegister(INT_TIMER1A, timer2_interrupt);//associa a interrup��o do timer1_A a fun��o "timer2_interrupt"
	IntEnable(INT_TIMER1A);								//habilita o timer1_A
	TimerIntEnable(TIMER1_BASE, TIMER_TIMA_TIMEOUT);
	TimerEnable(TIMER1_BASE, TIMER_A);

	//Timer0 configuration
	TimerConfigure(TIMER0_BASE, TIMER_CFG_PERIODIC);//configura timer1 para onda completa
	TimerLoadSet(TIMER0_BASE, TIMER_A,TIVA_FREQUENCY*10 );//configura o timerA para um periodo de 10s
	IntRegister(INT_TIMER0A, timer1_interrupt);//associa a interrup��o do timer1_A a fun��o "timer2_interrupt"
	IntEnable(INT_TIMER0A);								//habilita o timer1_A
	TimerIntEnable(TIMER0_BASE, TIMER_TIMA_TIMEOUT);
	TimerEnable(TIMER0_BASE, TIMER_A);

}

void main (){
#define _s_size 200
	char _s[_s_size] = {0};
	unsigned char response = 0;
	char msg[50]={0};
	unsigned char i;

	setup();

	//Setup mac_list

	strncpy(mac_list,MAC_ESCRAVO_TESTE,MAC_SIZE);
	debugUart("Modulo Fixo iniciado!\r\n");
	//putStringUart("$$$");
	putStringUart("---\r\n");
	timeout = 200;
	while( timeout > 0 );
	setup_BT();

	while(1){

		if(call_inquiry_flag == 1){

			inquiryOnGoing = 1;
			debugUart("Iniciando Inquiry\r\n");
			memset(_s,0,_s_size);
			response = inquiry_process(_s,3);
			sprintf(msg,"Mac achados: %d\r\n",response);
			debugUart(msg);
			if(response > 0){
				debugUart("Enderecos encontrados:\r\n");
				for(i=0;i<response;i++){
					strncpy(msg,&(_s[12*i]),12);
					debugUart(msg);
					debugUart("\r\n");
				}
			}
			inquiryOnGoing = 0;
			call_inquiry_flag = 0;
		}
	}
}



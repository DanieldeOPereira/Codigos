#include <stdbool.h>
#include <stdio.h>
#include <string.h>
//#include <stdint.h>
#include "bt_mestre_teste.h"
#include "uart.h"
//#include "driverlib/uart.h"
//#include "inc/hw_memmap.h"


extern volatile unsigned int timeout;
extern unsigned char mac_list[20][12];

//void putCharBT(char * _s){
//	unsigned int i;
//	for(i=0; i< strlen(_s); i++){
//		UARTCharPut(UART3_BASE, _s[i]);
//	}
//}

unsigned char enter_AT_mode(){
	char _s[10]={0};
	unsigned char aux=0;
	putStringUart("\n");
	timeout = 100;
	while((timeout>0) && (aux < 10)){
		if(caracteres_disponiveis() > 0){
			_s[aux++] = ler_caracter();
			if(strstr(_s,"?") != NULL)
				return 1;
		}
	}
	putStringUart("---\r\n");
	timeout = 200;
	while(timeout>0);
	aux=0;
	putStringUart("$$$");
	timeout = 500;
	while((timeout>0) && (aux < 10)){
		if(caracteres_disponiveis() > 0){
			_s[aux++] = ler_caracter();
			if(strstr(_s,"CMD") != NULL)
				return 1;
		}
	}
	return 0;
	//putStringUart("\r\n");
}

unsigned char inquiry_process(unsigned char * resposta, unsigned char inquiry_duration){
	char _s[200]={0}, msg[50]={0};
	char mac_test[13]={0};
	unsigned char i,pos=0,aux=0;
	unsigned char n_addr_match=0;

	// Entrar modo AT
	if(enter_AT_mode() == 1){
	// Make inquiry

		sprintf(msg,"I,%d\r\n",inquiry_duration);
		putStringUart(msg);
	// Wait inquiry_done string
		timeout = (((unsigned int) inquiry_duration) * 1000) + 5000;
		while( (timeout > 0) && (pos < 200) ){
			while(caracteres_disponiveis() > 0)
				_s[pos++] = ler_caracter();
			if(strstr(_s,"Inquiry Done") != NULL){
				break;
			}
		}
		if(strstr(_s,MAC_ESCRAVO_TESTE)){
			debugUart("\r\nMac de teste encontrado! Iniciando conexao!\r\n");
			memset(_s,0,sizeof(_s));
			sprintf(msg,"C,%s\r\n",MAC_ESCRAVO_TESTE);
			putStringUart(msg);
			debugUart(msg);
			debugUart("\r\n");
			timeout = 6000;
			pos = 0;
			while( (timeout > 0) && (pos < 200) ){
				while(caracteres_disponiveis() > 0)
					_s[pos++] = ler_caracter();
				if((strstr(_s,"%CONNECT") != NULL) || (strstr(_s,"CONNECTED") != NULL)){
					break;
				}
				else if(strstr(_s,"failed") != NULL){
					break;
				}
			}
			if((strstr(_s,"%CONNECT") != NULL) || (strstr(_s,"CONNECTED") != NULL)){
				timeout = 400;
				while(timeout>0);
				putStringUart(SENHA_ESCRAVO_TESTE);
				timeout = 3000;
				memset(_s,0,sizeof(_s));
				pos = 0;
				while( (timeout > 0) && (pos < 200) ){
					while(caracteres_disponiveis() > 0)
						_s[pos++] = ler_caracter();
					if(strstr(_s,"OK PASSWORD") != NULL){
						putStringUart("%");
						break;
					}
					else if(strstr(_s,"failed") != NULL){
						putStringUart("R,1\r\n");
						break;
					}
				}
			}
			else{
				putStringUart("R,1\r\n");
			}
		}


	// Se achar "Inquiry Done"  // n�o funcionando :(
//		if(strstr(_s,"Inquiry Done") != NULL){
//			debugUart("[inquiry_process] Inquiry Done encontrado!\r\n");
//
//
//			// return number of ADDR match
//		}
//		else if(strstr(_s,"No Devices Found") != NULL){
//			debugUart("[inquiry_process] 0 dispositivos no local!\r\n");
//		}
//		else{
//			debugUart("[inquiry_process] Erro, Inquiry Done nao recebido!\r\n");
//		}

	}
	else{
		debugUart("[inquiry_process] Erro ao entrar modo AT!\r\n");
	}
	// Sai do modo AT
	timeout = 200;
	while(timeout>0);
	putStringUart("---\r\n");
	timeout = 200;
	while(timeout>0);
	putStringUart("%");
	return 0;
}

void setup_BT(){
	char _s[20]={0};
	unsigned char pos=0;
	unsigned char aux=0;

	if(enter_AT_mode() == 1 ){
		putStringUart("SO,%\r\n");
		timeout = 400;
		while((timeout>0) && (pos < 10)){
			if(caracteres_disponiveis() > 0){
				_s[pos++] = ler_caracter();
				if(strstr(_s,"AOK") != NULL){
					debugUart("BT configurado! Reiniciando...\r\n");
					break;
				}
			}
		}
		if(timeout == 0)
			debugUart("BT nao configurado! AOK nao veio! Vish...\r\n");
		else{
			memset(_s,0,sizeof(_s));
			putStringUart("R,1\r\n");
			timeout = 1000;
			while((timeout>0) && (aux < 20)){
				if(caracteres_disponiveis() > 0){
					_s[aux++] = ler_caracter();
					if(strstr(_s,"REBOOT") != NULL){
						debugUart("\r\nReinicio Detectado!\r\n");
						return;
					}

				}
			}
		}
	}
	else
		debugUart("Erro! Nao entrou no modo AT!\r\n");
}



#ifndef _BT_TEST_H_
#define _BT_TEST_H_

#define INQUIRY_TIMEOUT 7000
#define MAC_ESCRAVO_TESTE "00066668364F"
#define MAC_SIZE 12
#define SENHA_ESCRAVO_TESTE "1234123412341234"

unsigned char inquiry_process(unsigned char * resposta, unsigned char inquiry_duration);
void setup_BT(void);

#endif

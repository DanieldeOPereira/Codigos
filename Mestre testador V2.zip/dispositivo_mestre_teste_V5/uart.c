#include "uart.h"
#include "inc/hw_memmap.h"
#include <stdbool.h>
#include <stdint.h>
#include "driverlib/uart.h"
#include <stdio.h>
#include <string.h>

extern volatile unsigned int timeout;
volatile unsigned char uartBuffer[UART_BUFFER_SIZE]={0};
unsigned char uartPosition=0, readedPosition=0;

void flush_uart(void){
	uartPosition = 0;
	readedPosition = 0;
	memset(uartBuffer,0,sizeof(uartBuffer));
}

unsigned int caracteres_disponiveis(void){
	if(uartPosition>=readedPosition)
		return (uartPosition-readedPosition);
	else
		return (UART_BUFFER_SIZE + uartPosition - readedPosition);
}

unsigned char salvar_caracter(unsigned char _c, unsigned char test_caracter){
	/*
		retorno:
		1 = salvo com sucesso
		2 = caracter de teste encontrado e nÃƒÂ£o salvo
	*/
	if(_c == test_caracter)
		return 2;
	else{
		uartBuffer[uartPosition] = _c;
		uartPosition++;
		if(uartPosition==UART_BUFFER_SIZE)
			uartPosition=0;
		return 1;
	}
}

unsigned char ler_caracter(void){
	unsigned char _c = uartBuffer[readedPosition];
	if(caracteres_disponiveis > 0){
		readedPosition++;
		if(readedPosition == UART_BUFFER_SIZE)
			readedPosition = 0;
		return _c;
	}
	else
		return 255; //falha
}

void putStringUart(char * _s){
	unsigned int i;
	for(i=0; i< strlen(_s); i++){
		while(UARTBusy(UART3_BASE));
		UARTCharPutNonBlocking(UART3_BASE, _s[i]);
	}
}

void debugUart(char * _s){
	unsigned int i;
		for(i=0; i< strlen(_s); i++){
			while(UARTBusy(UART0_BASE));
			UARTCharPutNonBlocking(UART0_BASE, _s[i]);
		}
//	while(*_s != '\0')
//			UARTCharPut(UART0_BASE, *_s);
}

unsigned char send_command(char * comando, char * expected_answer1, char * expected_answer2, unsigned int timeout_comando, uint32_t UART_X){
#define buffer_size 250
	char _s[buffer_size]={0};
	unsigned int buffer_position=0;
	unsigned char answer = 0;
	if(UART_X == UART3_BASE){
		putStringUart(comando);
	}
	else if(UART_X == UART0_BASE){
		debugUart(comando);
	}
	else{
		return 0;
	}
	timeout = timeout_comando;
	while((timeout > 0) && (buffer_position < buffer_size)){
		if(caracteres_disponiveis() > 0){
			_s[buffer_position++] = ler_caracter();
			if(strstr(_s,expected_answer1) != NULL){
				answer = 1;
				break;
			}
			else if(strstr(_s,expected_answer2) != NULL){
				answer = 2;
				break;
			}
		}
	}
	if((timeout == 0) && (answer == 0))
		answer = 3;
	return answer;
}
